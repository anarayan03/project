package exception;

public class NameException extends Exception
{

	public NameException(String str)
	{
		System.out.println(str);
	}
	
}
